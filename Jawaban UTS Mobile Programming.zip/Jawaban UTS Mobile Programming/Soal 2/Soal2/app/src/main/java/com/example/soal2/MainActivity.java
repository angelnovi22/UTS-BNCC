package com.example.soal2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private Button buttonSaveType, buttonSubmit, buttonTestDrive;
    private TextView textTipeKendaraan, textBrand, textName, textLicence, textTopSpeed, textGasCapacity, textWheel, textTypeMobil, textTypeMotor, textESA, textJumlahHelm, textKendaraan, textViewDescription, textPrice, textHarga;
    private EditText textFieldTipeKendaraan, textFieldBrand, textFieldName, textFieldLicence, textFieldTopSpeed, textFieldGasCapacity, textFieldWheel, textFieldTypeMobil, textFieldTypeMotor, textFieldESA, textFieldJumlahHelm, textFieldHargaHelm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textTipeKendaraan = (TextView) findViewById(R.id.textView);
        textBrand = (TextView) findViewById(R.id.textBrand);
        textName = (TextView) findViewById(R.id.textName);
        textLicence = (TextView) findViewById(R.id.textLicence);
        textTopSpeed = (TextView) findViewById(R.id.textTopSpeed);
        textGasCapacity = (TextView) findViewById(R.id.textGasCapacity);
        textWheel = (TextView) findViewById(R.id.textWheel);
        textTypeMobil = (TextView) findViewById(R.id.textTypeMobil);
        textTypeMotor = (TextView) findViewById(R.id.textTypeMotor);
        textESA = (TextView) findViewById(R.id.textESA);
        textJumlahHelm = (TextView) findViewById(R.id.textJumlahHelm);
        textViewDescription = (TextView) findViewById(R.id.textViewDescription);
        textPrice = (TextView) findViewById(R.id.textPrice);
        textHarga = (TextView) findViewById(R.id.textHarga);

        textFieldTipeKendaraan = (EditText) findViewById(R.id.textFieldTipeKendaraan);
        textFieldBrand = (EditText) findViewById(R.id.textFieldBrand);
        textFieldName = (EditText) findViewById(R.id.textFieldName);
        textFieldLicence = (EditText) findViewById(R.id.textFieldLicence);
        textFieldTopSpeed = (EditText) findViewById(R.id.textFieldTopSpeed);
        int textFieldTS = Integer.parseInt(textFieldTopSpeed.getText().toString());
        textFieldGasCapacity = (EditText) findViewById(R.id.textFieldGasCapacity);
        int textFieldGC = Integer.parseInt(textFieldGasCapacity.getText().toString());
        textFieldWheel = (EditText) findViewById(R.id.textFieldWheel);
        int textFieldW = Integer.parseInt(textFieldWheel.getText().toString());
        textFieldTypeMobil = (EditText) findViewById(R.id.textFieldTypeMobil);
        textFieldTypeMotor = (EditText) findViewById(R.id.textFieldTypeMotor);
        textFieldESA = (EditText) findViewById(R.id.textFieldESA);
        int textFieldE = Integer.parseInt(textFieldESA.getText().toString());
        textFieldJumlahHelm = (EditText) findViewById(R.id.textFieldJumlahHelm);
        int textFieldJH = Integer.parseInt(textFieldJumlahHelm.getText().toString());
        textFieldHargaHelm = (EditText) findViewById(R.id.textFieldWheel);
        int textFieldH = Integer.parseInt(textFieldHargaHelm.getText().toString());

        if (textFieldBrand.length() < 5) {
            textFieldBrand.setError("minimal 5 character");
        } else if (textFieldName.length() < 5) {
            textFieldName.setError("minimal 5 character");
        } else if (textFieldLicence) {
            textFieldLicence.setError("");
        } else if (textFieldTS < 100 || textFieldTS > 250) {
            textFieldTopSpeed.setError("di antara 100 dan 250");
        } else if (textFieldGC < 30 || textFieldGC > 60) {
            textFieldGasCapacity.setError("di antara 30 dan 60");
        } else if (textFieldE < 1) {
            textFieldESA.setError("minimal 1");
        } else if (textFieldJH < 1) {
            textFieldJumlahHelm.setError("minimal 1");
        }

        buttonSaveType = (Button) findViewById(R.id.buttonSaveType);
        buttonSaveType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textFieldTipeKendaraan.getText().toString() == "Mobil") {
                    textTypeMotor.setVisibility(View.GONE);
                    textFieldTypeMotor.setVisibility(View.GONE);
                    textJumlahHelm.setVisibility(View.GONE);
                    textFieldJumlahHelm.setVisibility(View.GONE);
                    if (textFieldW < 4 || textFieldW > 6) {
                        textFieldWheel.setError("minimal 4 dan maximal 6");
                    }
                } else if (textFieldTipeKendaraan.getText().toString() == "Motor") {
                    textTypeMobil.setVisibility(View.GONE);
                    textFieldTypeMobil.setVisibility(View.GONE);
                    textESA.setVisibility(View.GONE);
                    textFieldESA.setVisibility(View.GONE);
                    if (textFieldW < 2 || textFieldW > 3) {
                        textFieldWheel.setError("minimal 2 dan maximal 3");
                    }
                }
            }
        });
        {

        }

        buttonSubmit = (Button) findViewById(R.id.buttonSubmit);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!textFieldTipeKendaraan.getText().toString().isEmpty() && !textFieldBrand.getText().toString().isEmpty() && !textFieldName.getText().toString().isEmpty() && !textFieldLicence.getText().toString().isEmpty() && !textFieldTopSpeed.getText().toString().isEmpty() && !textFieldGasCapacity.getText().toString().isEmpty() && !textFieldWheel.getText().toString().isEmpty() && !textFieldTipeKendaraan.getText().toString().isEmpty() && !textFieldTypeMobil.getText().toString().isEmpty() && !textFieldTypeMotor.getText().toString().isEmpty() && !textFieldESA.getText().toString().isEmpty() && !textFieldJumlahHelm.getText().toString().isEmpty()) {
                    if (textFieldTipeKendaraan.getText().toString() == "Mobil") {
                        textKendaraan.setText("Car" + textFieldName.getText().toString());
                        textViewDescription.setText("Brand: " + textFieldBrand.getText().toString() + "\n" + "Name: " + textFieldName.getText().toString() + "\n" + "License Plate: " + textFieldLicence.getText().toString() + "\n" + "Type: " + textFieldTypeMobil.getText().toString() + "\n" + "Gas Capacity: " + textFieldGasCapacity.getText().toString() + "\n" + "Top Speed: " + textFieldTopSpeed.getText().toString() + "\n" + "Wheel(s): " + textFieldWheel.getText().toString() + "\n" + "Entertianment System: " + textFieldESA.getText().toString());
                    } else if (textFieldTipeKendaraan.getText().toString() == "Motor") {
                        textKendaraan.setText("Motorcycle" + textFieldName.getText().toString());
                        textViewDescription.setText("Brand: " + textFieldBrand.getText().toString() + "\n" + "Name: " + textFieldName.getText().toString() + "\n" + "License Plate: " + textFieldLicence.getText().toString() + "\n" + "Type: " + textFieldTypeMotor.getText().toString() + "\n" + "Gas Capacity: " + textFieldGasCapacity.getText().toString() + "\n" + "Top Speed: " + textFieldTopSpeed.getText().toString() + "\n" + "Wheel(s): " + textFieldWheel.getText().toString() + "\n" + "Helm: " + textFieldJumlahHelm.getText().toString());
                    }

                }
            }
        });
        {
        }

     createSnackbar();

    }

    private void createSnackbar(){
        buttonTestDrive = (Button) findViewById(R.id.buttonTestDrive);
        buttonTestDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(textFieldTipeKendaraan.getText().toString() == "Mobil"){
                   if(textFieldTypeMobil.getText().toString() == "SUV" && textFieldTypeMobil.getText().toString() == "Minivan"){
                       Snackbar.make(view, "Turning on entertianment system...\n" + "Entertianment system amount " + textFieldESA.getText().toString(), Snackbar.LENGTH_LONG).setAnimationMode(BaseTransientBottomBar.ANIMATION_MODE_FADE).setBackgroundTint(Color.parseColor("#006400")).show();
                   }else{
                       Snackbar.make(view, "Boosting!", Snackbar.LENGTH_LONG).setAnimationMode(BaseTransientBottomBar.ANIMATION_MODE_FADE).setBackgroundTint(Color.parseColor("#006400")).show());
                   }
               }else {
                   Snackbar.make(view, textFieldName.getText().toString() + " is standing!", Snackbar.LENGTH_LONG).setAnimationMode(BaseTransientBottomBar.ANIMATION_MODE_FADE).setBackgroundTint(Color.parseColor("#006400")).show());
                    textPrice.setVisibility(View.VISIBLE);
                    textFieldHargaHelm.setVisibility(View.VISIBLE);
                    textHarga.setText("Price: " + textFieldHargaHelm);
                }
            }
        });
    }
}